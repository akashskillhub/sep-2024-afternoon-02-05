import React from 'react'

const PublicProtected = () => {
    return (
        <div>PublicProtected</div>
    )
}

export default PublicProtected