import React from 'react'

const SellerProfile = () => {
    return (
        <div>SellerProfile</div>
    )
}

export default SellerProfile