import { useFormik } from 'formik'
import * as yup from 'yup'
import { Link } from 'react-router-dom'

const Login = () => {
    const formik = useFormik({
        initialValues: {
            email: "",
            password: "",
        },
        validationSchema: yup.object({
            email: yup.string().email().required(),
            password: yup.string().required(),
        }),
        onSubmit: (values, { resetForm }) => {
            resetForm()
        }
    })
    return <>
        <form onSubmit={formik.handleSubmit}>
            <input {...formik.getFieldProps("email")} type="email" placeholder='email' />
            <input {...formik.getFieldProps("password")} type="password" placeholder='password' />
            <button type='submit'>login</button>
        </form>

        <Link to="/register">dont have account? register here</Link>
    </>
}

export default Login